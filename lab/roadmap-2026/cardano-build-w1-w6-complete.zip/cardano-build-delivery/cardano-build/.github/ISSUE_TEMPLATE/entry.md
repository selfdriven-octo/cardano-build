---
name: New entry submission
about: Propose a new tool, library, service, channel, or person for the cardano.build catalogue
title: 'Entry: '
labels: 'entry-submission'
---

<!--
Thanks for proposing a new entry. The maintainers will review and (if accepted)
create the JSON file under data/entries/ matching schema/v1.json.

If you're already comfortable with the repo: fork it, add your entry JSON, and
open a PR instead — that's faster than this issue route.
-->

## Entry details

- **Name:**
- **URL:**
- **Repository (if open source):**
- **One-line summary** (8-240 chars):

## Classification

- **Primary category** (from the enum in schema/v1.json — e.g. `onchain-language`, `offchain-library`, `infrastructure`):
- **Other categories** (if any):
- **Personas this serves** (one or more of: `evm`, `web2`, `founder`, `haskell-veteran`, `researcher`, `auditor`):
- **Programming languages relevant:**
- **Status:** `active` / `maintained` / `experimental` / `stale` / `deprecated` / `archived`
- **License (SPDX):**
- **Maintainers** (GitHub handles or org names):

## Supplementary links (optional)

- Tutorial / video / blog post / interview:
- Other reference:

## Why this belongs on cardano.build

<!-- A short paragraph. Helps the maintainers decide. -->
