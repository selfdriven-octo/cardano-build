---
name: Bounty submission
about: List an externally-funded bounty on the cardano.build bounty board
title: 'Bounty: '
labels: 'bounty-submission'
---

<!--
cardano.build does NOT custody bounty funds. We only surface bounties so they're
discoverable. Every bounty must have a real funder and a canonical URL where
contributors can claim it.

If you're funding the bounty yourself, link to the issue / Catalyst proposal /
funder's board where the work is tracked.
-->

## Bounty details

- **Title:**
- **Summary** (what needs to be built, why, and acceptance criteria — be specific):

## Funding

- **Amount in ada:**
- **USD estimate at time of listing (optional):**
- **Funder** (one of: `cbu-devx-2026`, `catalyst`, `intersect`, `cardano-foundation`, `selfdriven-foundation`, `project-specific`, `community`):
- **Canonical URL where the bounty is tracked:**

## Classification

- **Category** (one of: `onchain-offchain-interop`, `hardfork-readiness`, `introspection-serialization`, `documentation`, `sdk-integration`, `tooling-gap`, `design-pattern`, `audit`, `other`):
- **Skills required:**
- **Links to which catalogue entry** (e.g. `aiken`, `meshjs`):

## Dates

- **Opened:**
- **Closes (if any):**

## Why this belongs on the board

<!-- Short paragraph. Maintainers will reject bounties without a real funder or scope. -->
