---
name: Gap report
about: Report a developer-experience gap, missing tool, stale doc, or onboarding friction
title: 'Gap: '
labels: 'gap-report'
---

<!--
Gaps feed the DevX Initiative's Reactive workstream and the cardano.build
editorial backlog. The more specific you can be, the more useful this is.

If you've already hit this — name the exact path you took, the version of the
tool, and what you expected vs what happened.
-->

## What's missing or broken

- **Title** (one line):
- **Description** (what happened, what you expected, why it matters):

## Classification

- **Kind** (one of: `missing-tool`, `missing-docs`, `stale-content`, `broken-link`, `duplicate-effort`, `onboarding-friction`, `persona-mismatch`, `schema-issue`, `other`):
- **Severity:** `nice-to-have` / `moderate` / `blocker`
- **Personas affected** (one or more of: `evm`, `web2`, `founder`, `haskell-veteran`, `researcher`, `auditor`):
- **Catalogue entry this relates to** (if any — e.g. `aiken`, `meshjs`):

## Reporter

- **Reported by** (GitHub handle, name, or `anonymous`):
- **Date reported:**

## Suggested resolution (optional)

<!-- If you have ideas, drop them here. Pull requests welcome. -->
