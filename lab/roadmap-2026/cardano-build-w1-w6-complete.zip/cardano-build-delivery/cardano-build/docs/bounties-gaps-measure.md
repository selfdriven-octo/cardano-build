# Bounties, gaps & hackathon — W4 + W5

Workstreams W4 and W5 of the [DevX Initiative roadmap](../ROADMAP.md) build on the W2 data layer to expose three new surfaces:

- **`/bounties.html`** — open bounties surfaced from external funders
- **`/gaps.html`** — community-reported developer-experience gaps
- **`/measure.html`** — the Q4 2026 measurement hackathon hub

All three are static, machine-readable, and CC0. cardano.build does not custody bounty funds, does not pay out, and does not run the measurement event itself — it surfaces them for discoverability.

## Bounties (W4)

### Schema

`schema/bounty-v1.json` defines the bounty record. Required fields:

| Field | Notes |
|---|---|
| `id` | Stable kebab-case identifier. Must match filename. |
| `title` | Short bounty title. |
| `summary` | What needs to be built, why, and acceptance criteria. |
| `url` | Canonical URL where the bounty is tracked (GitHub issue, Catalyst proposal, funder's board). |
| `amount_ada` | Bounty amount in ada. 0 if TBD or denominated in another currency. |
| `source` | Funding source: `cbu-devx-2026`, `catalyst`, `intersect`, `cardano-foundation`, `selfdriven-foundation`, `project-specific`, `community`. |
| `status` | `open`, `assigned`, `in-review`, `completed`, `closed`, `expired`. |
| `opened` | Date opened (YYYY-MM-DD). |

Optional: `amount_usd_estimate`, `linked_entry` (catalogue entry id), `category`, `skills`, `closes`, `assignee`.

### Adding a bounty

1. Copy a file from `data/bounties/` and rename to `{your-id}.json`. The `id` field must match.
2. Fill in the fields. Make sure the `url` actually links somewhere a contributor can claim the bounty.
3. `npm run build` validates and rebuilds `api/v1/bounties.json`.
4. Open a PR.

Or open a GitHub issue with the `bounty.md` template — a maintainer will convert it.

### What the build script enforces

- Schema validation against `schema/bounty-v1.json`
- `linked_entry` must resolve to a known catalogue entry id
- `id` must match filename

### Outputs

```
api/v1/bounties.json          all bounties + aggregate counts + open ada pool
```

## Gaps (W4)

### Schema

`schema/gap-v1.json` defines the gap record. Required fields: `id`, `title`, `description`, `kind`, `reported_by`, `reported`, `status`.

Gap **kinds**: `missing-tool`, `missing-docs`, `stale-content`, `broken-link`, `duplicate-effort`, `onboarding-friction`, `persona-mismatch`, `schema-issue`, `other`.

Gap **severities**: `nice-to-have`, `moderate`, `blocker`.

Gap **statuses**: `open`, `triaged`, `in-progress`, `resolved`, `wont-fix`, `duplicate`.

### Adding a gap

1. Open a GitHub issue with the `gap.md` template — fastest path.
2. Or copy a file from `data/gaps/` and submit via PR.

Resolved gaps stay in the dataset with `status: resolved` and a `resolution_notes` field. They surface in the collapsed "Resolved gaps" section of `/gaps.html`, providing a public audit trail of what's been fixed.

### Outputs

```
api/v1/gaps.json              all gaps + aggregate counts by status
```

## Hackathon (W5)

### Schema

The hackathon record is less rigidly typed than bounties/gaps — events are unique enough that strict schema validation isn't worth the friction. Required: `id`, `name`, `tagline`, `starts`, `ends`.

Files in `data/hackathon/` each describe one event. The current one is `measure-2026-q4.json` — the DevX Measurement Hackathon.

### What it measures

The page surfaces five concrete metrics: time-to-first-tx, time-to-first-validator, DevX NPS, friction points logged, stack-permutation coverage. This is described as a *controlled* measurement event — participants get assigned stacks, problem scope is fixed, and friction is logged in real time. The output is a CC0 data set future events can re-baseline against.

### Outputs

```
api/v1/hackathon/{id}.json    one file per hackathon event
```

## How the proposal's Reactive workstream uses this

The DevX Initiative proposal includes a Reactive line — "high-ROI opportunities surfaced through ecosystem alignment" that fund continued or new development. cardano.build's gap tracker is the most explicit feed for that line: every triaged gap with `severity: moderate` or `blocker` becomes a candidate for the Reactive pool.

When the proposal team adopts a gap, the gap's `status` moves to `in-progress` and a `linked_bounty` field is added pointing at the corresponding bounty record. When the work ships, both records update to `resolved` / `completed` and `resolution_notes` documents what happened.

This creates a closed-loop public record from "developer hits friction" → "gap reported" → "bounty funded" → "work shipped" → "catalogue improved" — all CC0, all KERI-anchored via the nightly snapshot digest.

## CI

Bounties and gaps validate as part of the standard build. A pull request that breaks schema validation, references unknown catalogue entries, or breaks linked bounty references fails CI before merge.

## Front-end pages

```
/bounties.html       reads /api/v1/bounties.json — board with filters
/gaps.html           reads /api/v1/gaps.json — board with severity + kind filters, resolved section
/measure.html        reads /api/v1/hackathon/measure-2026-q4.json — event hub
```

All three are static, persona-agnostic, and consume their data via fetch on page load. They work without any backend; they only require the build pipeline to have run.
