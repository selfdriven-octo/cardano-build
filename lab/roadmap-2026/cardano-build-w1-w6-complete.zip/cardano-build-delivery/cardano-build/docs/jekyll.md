# Jekyll + publish.js — W6

The W6 refactor took 8 standalone HTML files and rebuilt them on a **Jekyll-compatible source tree** that also renders **offline via a Node-based `publish.js`-style script**. Same source, two render paths.

## The two render paths

**Path A — GitHub Pages (Jekyll):** push to `main`, GitHub Pages runs `jekyll build` with the `github-pages` gem, the site is live. Zero local Ruby required.

**Path B — Local preview (`scripts/preview.mjs`):** `npm run preview` reads the exact same Jekyll source tree using `liquidjs` + `gray-matter` + `js-yaml`, writes rendered HTML to `public/`. Mirrors selfdriven Studio's `publish.js` conventions.

Both paths produce byte-identical output for every page that doesn't use Jekyll-only filters. The Liquid filters we registered (`relative_url`, `strip_newlines`) match Jekyll's behaviour exactly.

## Directory layout

```
_layouts/          Jekyll layouts
  default.html       head + nav + content + footer shell
  page.html          extends default with optional hero scaffold

_includes/         shared partials
  head.html          <head> tags, fonts, css
  nav.html           top nav (data-driven from _data/nav.yml)
  footer.html        site footer (data-driven from _data/footer.yml)

_data/             single source of truth — edit these to update site-wide
  site.yml           brand strings, URLs, proposal alignment, maintainer
  nav.yml            nav link list + current-class key
  footer.yml         footer column groups + links

assets/
  css/site.css       shared design tokens, base typography, nav/footer/hero/section primitives
                     (Front-matter at top so Liquid processes it; future Liquid in CSS is supported.)

scripts/
  build.mjs          existing W2-W5 pipeline (catalogue/bounties/gaps/hackathon/llms.txt/RSS/MCP/snapshot)
  preview.mjs        new W6 Liquid renderer (Jekyll-compatible)
  check-links.mjs    nightly link-rot checker

<root>/*.html      pages. Each has Jekyll front matter and is processed by the
                   layout it declares. Pages with heavy JS template literals
                   wrap their <script> in {% raw %}...{% endraw %}.
```

Top-level `_config.yml` and `Gemfile` are the standard Jekyll/GitHub Pages files; nothing custom there.

## Front-matter conventions

Every page starts with YAML front-matter inside `---` delimiters:

```yaml
---
layout: default          # which _layouts/ template wraps this page
title: Bounties          # used in <title> via _includes/head.html
description: "…"         # used in <meta name=description>
nav_current: bounties    # match key against _data/nav.yml items.key for current class
---
```

A page that should be marked "active" in the top nav sets `nav_current` to the matching `key` from `_data/nav.yml`. Pages that have no obvious nav home (the home page itself, the persona dispatcher) use `nav_current: ""`.

## Adding a new page

1. Create `your-page.html` at the repo root with front matter and content:

   ```html
   ---
   layout: default
   title: Your page
   description: "What this page is about."
   nav_current: your-page
   ---

   <style>
   /* Only page-unique CSS. site.css already gives you all the brand tokens,
      nav/footer styles, hero scaffolding, sections, stats, CTAs, chips,
      skeleton, and the `.coming-soon` badge. */
   </style>

   <section class="hero">
     <span class="eyebrow">Your eyebrow</span>
     <h1>Your <em>title</em></h1>
     <p class="lede">Your lede.</p>
   </section>

   <section class="section">
     ...
   </section>
   ```

2. If the page should appear in the nav, add an entry to `_data/nav.yml`:

   ```yaml
   - key: your-page
     label: your page
     href: /your-page.html
   ```

3. Run `npm run preview` to render. Open `public/your-page.html` to verify.

If your page has JS template literals (`` `${foo}` ``) or any `{{ }}` /  `{% %}` syntax that Jekyll's Liquid would try to parse, wrap the whole `<script>` block in `{% raw %}…{% endraw %}`. Every JS-heavy page in this repo already does this — see `bounties.html`, `gaps.html`, `measure.html`, `persona.html`, `index.html`.

## Liquid filters

Beyond what Liquid ships with, the preview script registers two:

- **`relative_url`** — Jekyll-compatible. Prepends `/` for relative paths, leaves absolute URLs alone. Used by `_includes/head.html` to point at `/assets/css/site.css`.
- **`strip_newlines`** — Collapses internal whitespace. Used by `head.html` to flatten the multi-line `<meta name=description>`.

Both match Jekyll's stdlib filters of the same name.

## Page CSS strategy

`assets/css/site.css` covers:
- All design tokens (light + dark mode)
- Base typography and link styles
- `.nav`, `.brand`, `.nav-links`, `.nav-cta` (top nav)
- `.hero`, `.eyebrow`, `.coming-soon` (hero scaffolding)
- `.section`, `.section-head`, `.section-head--inline` (section primitive)
- `.stats`, `.stat` (stat strip used by bounties / gaps / measure)
- `.cta-bar`, `.cta-primary`, `.cta-secondary` (CTAs)
- `.toolbar`, `.toolbar-label`, `.chip`, `.filters` (filter chips)
- `.footer`, `.footer-inner`, `.footer-bottom` (site footer)
- `.skeleton`, `.empty`, `.reveal` (loading + empty states)

Each page's `<style>` block holds only its **page-unique** rules: bounty cards, gap cards, terminal preview, primitive cards, dictionary table, blessed paths, CIPs, etc. The `:root` token block, base body styles, and shared nav/footer rules are **never** duplicated inline — site.css owns them.

## Section-head: stacked vs inline

The shared `.section-head` defaults to stacked (eyebrow above heading). Add `section-head--inline` when you want side-by-side `<h2>` + `<span class="sub">` layout:

```html
<!-- Stacked (default) -->
<div class="section-head">
  <span class="eyebrow">EYEBROW</span>
  <h2>Heading</h2>
  <p>Description.</p>
</div>

<!-- Inline (heading + sub on same line) -->
<div class="section-head section-head--inline">
  <h2>Heading</h2>
  <span class="sub">5 items</span>
</div>
```

Catalogue, bounties, and gaps use the inline variant for their list headings. Most other section heads use stacked.

## Build pipeline integration

The full build is now three steps:

```
npm run check-links    # check link health (optional, slow)
npm run build          # validate data, emit api/v1/*, llms.txt, feed.rss, mcp.json, snapshot
npm run preview        # render Jekyll source to public/
```

Shortcuts:

- `npm run render` — build + preview (no link check)
- `npm run all` — link-check (with --update) + build + preview

After `npm run preview`, the `public/` directory contains:

```
public/
  *.html              rendered Jekyll pages
  assets/css/site.css rendered shared stylesheet
  api/v1/*            (staged from api/ by hand or by CI before serving)
  llms.txt
  feed.rss
  .well-known/mcp.json
```

For local preview: `cd public && python3 -m http.server 8765` (or any static server).

## CI

GitHub Pages picks up the Jekyll source automatically via the `github-pages` gem declared in the `Gemfile`. Every push to `main` triggers a Pages rebuild — no GitHub Action needed for the site itself.

The data validation job in `.github/workflows/build.yml` runs `npm run build` on every PR to ensure new entries, bounties, and gaps validate against their schemas. It does **not** run the Liquid render — Jekyll itself does that on the Pages side, and `npm run preview` is purely a developer-experience tool for local iteration.

## Why not Jekyll-only?

A pure Jekyll setup would require Ruby on every contributor's machine. `publish.js` style preview means anyone with Node 20 can render the site locally — same source tree, no Ruby. The selfdriven Studio toolchain follows this pattern (see `lab/build/publish.js` in `selfdriven-studio`); we kept the same conventions here so cardano.build feels native to selfdriven contributors.

## Migration notes

Pre-W6, every page had:
- Its own `<head>` tags duplicated
- Its own `:root` token block (208 lines duplicated × 7 pages = ~1,400 LOC)
- Its own `.nav`, `.brand`, `.nav-links`, `.nav-cta` CSS rules
- Its own `.footer` CSS rules
- Hard-coded nav link list (8 entries × 7 pages = 56 anchor tags)
- Hard-coded footer column structure

Post-W6, all of that lives in `_layouts/` + `_includes/` + `_data/` + `assets/css/site.css`. To change the brand colour, edit `--accent` in one place. To rename a nav link, edit `_data/nav.yml`. To add a footer link, edit `_data/footer.yml`. The pages themselves got 24% smaller (3,276 → 2,478 LOC) while gaining maintainability.
