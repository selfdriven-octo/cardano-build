# cardano.build data layer — W2

The `data/entries/` directory holds the machine-readable source of truth for everything indexed on [cardano.build](https://cardano.build). Every entry is a single JSON file validated against [`schema/v1.json`](../schema/v1.json).

This replaces the old freeform `data/cardano-build.yaml` queue for *catalogued* entries. The queue still exists for new submissions that haven't yet been triaged into typed entries.

## Why typed entries?

The current cardano.build page is hand-curated HTML, beautiful and broad but not machine-readable. The W2 workstream of the [DevX Initiative roadmap](../ROADMAP.md) introduces a typed schema so that:

- Every entry has explicit **persona affinity** (EVM, Web2, founder, ...) — enabling persona-specific landing pages (W1)
- Every entry has **status** and **last_checked** — enabling stale-link detection (W4)
- The catalogue is exposed as **JSON, RSS, llms.txt, and MCP** — so coding agents (Claude, ChatGPT, Cursor) can recommend Cardano tooling
- Every nightly snapshot is **KERI-anchored** via selfdriven Octo — giving the dataset a verifiable audit trail

The Developer HUB at [developers.cardano.org](https://developers.cardano.org) remains the canonical onboarding tutorial source. cardano.build is the **discovery index** that points to it and the rest of the ecosystem.

## Adding a new entry

1. Copy an existing entry from `data/entries/` and rename to `{your-id}.json`. The `id` field MUST match the filename (minus `.json`).
2. Edit the fields. Required: `id`, `name`, `summary`, `url`, `categories`, `personas`, `status`, `added`, `updated`. Everything else is optional.
3. Run `npm run build` locally — this validates the schema and regenerates `api/`, `public/`, and `data/snapshot.*`.
4. Open a pull request.

Minimum viable entry:

```json
{
  "id": "your-tool",
  "name": "Your Tool",
  "summary": "One sentence describing what it does and who it's for.",
  "url": "https://example.com",
  "categories": ["offchain-library"],
  "personas": ["web2"],
  "status": "active",
  "added": "2026-05-13",
  "updated": "2026-05-13"
}
```

## Fields explained

### Required

| Field | Notes |
|---|---|
| `id` | Stable kebab-case identifier. Never changes once published. Must match filename. |
| `name` | Display name. |
| `summary` | One sentence (8-240 chars), plain prose, no markdown. |
| `url` | Canonical project URL. |
| `categories` | One or more from the enum in `schema/v1.json`. First = primary. |
| `personas` | Which proposal personas this entry serves. At least one. |
| `status` | `active`, `maintained`, `experimental`, `stale`, `deprecated`, or `archived`. |
| `added` | YYYY-MM-DD. Date first added to the catalogue. |
| `updated` | YYYY-MM-DD. Date of last meaningful update. |

### Recommended

| Field | Notes |
|---|---|
| `repository` | Source repository if open source. Enables maintainer auto-discovery. |
| `docs` | Docs URL if different from `url`. |
| `languages` | Programming languages from the enum. Helps language-based filtering. |
| `license` | SPDX identifier (`MIT`, `Apache-2.0`, `CC0-1.0`, etc.). |
| `maintainers` | GitHub handles or organisation names. |
| `tags` | Free-form lowercase kebab-case tags. Use `blessed-stack` for entries the roadmap explicitly recommends. |
| `last_release` | YYYY-MM-DD. Auto-updatable from GitHub. |
| `last_checked` | YYYY-MM-DD. Set by the nightly link checker. Do not edit by hand. |
| `links` | Supplementary links (videos, tutorials, interviews). |

### Set by the pipeline

| Field | Notes |
|---|---|
| `keri_anchor` | AID this entry was last anchored under. Set by `selfdriven Octo` KERI factory after merge. |

## Personas

The proposal targets three personas. cardano.build adopts them as first-class navigation:

- **`evm`** — developers coming from Ethereum, Solana, or other EVM-style ecosystems. Familiar with TypeScript, comfortable with on-chain abstractions, looking for the EUTXO equivalent of what they know.
- **`web2`** — developers from traditional web/mobile/backend backgrounds. Want a clear "blessed path" and might be writing their first smart contract.
- **`founder`** — technical entrepreneurs evaluating Cardano as a platform. Care about ecosystem strength, audited primitives, and time-to-MVP.

Three extension personas exist for completeness:
- **`haskell-veteran`** — comfortable with the original Plutus toolchain.
- **`researcher`** — academic or research lens.
- **`auditor`** — security review / formal verification lens.

An entry can belong to multiple personas; that's expected and encouraged for general-purpose tooling.

## Statuses

- **`active`** — under regular development, recent releases.
- **`maintained`** — stable, still updated, no major new features expected.
- **`experimental`** — early-stage, may break. Includes proposal deliverables not yet shipped.
- **`stale`** — no release in 12+ months but still works.
- **`deprecated`** — replaced. Set `deprecated_by` to the successor's `id`.
- **`archived`** — no longer maintained, kept for historical reference.

## Build outputs

Running `npm run build` produces:

```
api/v1/index.json                  full catalogue
api/v1/by-persona/{persona}.json   filtered slices per persona
api/v1/by-category/{cat}.json      filtered slices per category
public/llms.txt                    agent-readable site map (llmstxt.org)
public/feed.rss                    RSS feed of recent additions
public/.well-known/mcp.json        MCP server descriptor
data/snapshot.json                 deterministic nightly snapshot
data/snapshot.digest               sha256 of the snapshot (KERI anchor payload)
```

All of these are committed to the repo and served as static files. There is no server.

## CI

The workflow at `.github/workflows/build.yml`:

- Runs `npm run build` on every PR and push (fails the build if any entry is invalid).
- Nightly at 14:00 UTC: runs the link-rot check, updates `last_checked` for healthy entries, regenerates outputs, and commits the changes.
- Uploads a `link-check-report.json` artifact showing which entries failed.

## KERI anchoring

The selfdriven Octo workstream owns a KERI AID that anchors the cardano.build snapshot nightly. The flow:

1. CI produces `data/snapshot.json` (deterministic, sorted entry ids).
2. CI computes `data/snapshot.digest` (sha256).
3. selfdriven Octo's `app-process-cardano-build-anchor` factory method reads the digest and emits a KERI `ixn` event against the cardano.build AID.
4. The AID's KEL becomes the verifiable audit trail of every snapshot.

The KERI integration is deliberately decoupled from the build — the build works without it, and the anchoring runs in the selfdriven infrastructure. This keeps cardano.build's CI simple while still providing tamper-evident provenance for anyone who wants it.

See the [roadmap](../ROADMAP.md) for the full W2 specification.
