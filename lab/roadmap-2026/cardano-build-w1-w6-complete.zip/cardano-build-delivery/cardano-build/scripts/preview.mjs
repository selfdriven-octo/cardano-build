#!/usr/bin/env node
/**
 * cardano.build — Jekyll-compatible dev preview renderer
 *
 * Renders the Jekyll-style source tree (front matter + Liquid templates,
 * layouts, includes, _data) without requiring Ruby/Jekyll. Uses the same
 * conventions as selfdriven Studio's `publish.js` so the same source tree
 * works both in GitHub Pages (Jekyll) and locally (this script).
 *
 * Output goes to public/ — overwriting only the rendered HTML files.
 * Static assets emitted by scripts/build.mjs (api/, llms.txt, feed.rss,
 * .well-known/mcp.json) are left alone.
 *
 * Usage:  node scripts/preview.mjs
 */

import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Liquid } from "liquidjs";
import yaml from "js-yaml";
import matter from "gray-matter";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");

const LAYOUTS_DIR = path.join(ROOT, "_layouts");
const INCLUDES_DIR = path.join(ROOT, "_includes");
const DATA_DIR = path.join(ROOT, "_data");
const ASSETS_DIR = path.join(ROOT, "assets");
const PUBLIC_DIR = path.join(ROOT, "public");

// Pages live at the repo root. Anything matching this glob gets rendered.
const PAGE_FILES = [
  "index.html",
  "bounties.html",
  "gaps.html",
  "measure.html",
  "persona.html",
  "init.html",
  "contracts.html",
];

async function exists(p) {
  try { await fs.access(p); return true; } catch { return false; }
}

async function readData() {
  const data = {};
  try {
    const files = await fs.readdir(DATA_DIR);
    for (const f of files) {
      if (!f.endsWith(".yml") && !f.endsWith(".yaml")) continue;
      const name = path.basename(f, path.extname(f));
      const raw = await fs.readFile(path.join(DATA_DIR, f), "utf8");
      data[name] = yaml.load(raw);
    }
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  return data;
}

async function copyAssets() {
  if (!(await exists(ASSETS_DIR))) return;
  const dst = path.join(PUBLIC_DIR, "assets");
  await fs.rm(dst, { recursive: true, force: true });
  await fs.cp(ASSETS_DIR, dst, { recursive: true });
  console.log("  copied assets/ → public/assets/");
}

async function renderPage(filename, engine, siteCtx) {
  const srcPath = path.join(ROOT, filename);
  const raw = await fs.readFile(srcPath, "utf8");
  const { data: fm, content } = matter(raw);

  // Render the page body with Liquid using site + page context
  const ctx = { site: siteCtx, page: fm };
  let rendered = await engine.parseAndRender(content, ctx);

  // If the page declares a layout, wrap it
  let layoutName = fm.layout;
  // Cycle through layouts (a layout may reference another via its own front matter)
  const visited = new Set();
  while (layoutName) {
    if (visited.has(layoutName)) break;
    visited.add(layoutName);

    const layoutPath = path.join(LAYOUTS_DIR, `${layoutName}.html`);
    if (!(await exists(layoutPath))) {
      console.warn(`  ! layout not found: ${layoutName}`);
      break;
    }
    const layoutRaw = await fs.readFile(layoutPath, "utf8");
    const { data: layoutFm, content: layoutBody } = matter(layoutRaw);

    const wrapCtx = {
      site: siteCtx,
      page: fm,
      content: rendered,
    };
    rendered = await engine.parseAndRender(layoutBody, wrapCtx);

    layoutName = layoutFm.layout;
  }

  const outPath = path.join(PUBLIC_DIR, filename);
  await fs.mkdir(path.dirname(outPath), { recursive: true });
  await fs.writeFile(outPath, rendered, "utf8");

  return { src: filename, dst: path.relative(ROOT, outPath), size: rendered.length };
}

async function renderSiteCss(engine, siteCtx) {
  // The site CSS file has front matter so Liquid will process it. Render
  // it through the engine and write to public/assets/css/site.css.
  const src = path.join(ASSETS_DIR, "css/site.css");
  if (!(await exists(src))) return;
  const raw = await fs.readFile(src, "utf8");
  const { data: fm, content } = matter(raw);
  const rendered = await engine.parseAndRender(content, {
    site: siteCtx,
    page: fm,
  });
  const dst = path.join(PUBLIC_DIR, "assets/css/site.css");
  await fs.mkdir(path.dirname(dst), { recursive: true });
  await fs.writeFile(dst, rendered, "utf8");
  console.log(`  rendered assets/css/site.css → public/`);
}

async function main() {
  console.log("cardano.build preview renderer starting...\n");

  // Load _data
  const data = await readData();
  const siteCtx = {
    ...data.site, // expose _data/site.yml fields at top level under site.*
    data,         // and the full _data tree under site.data.*
    url: data.site?.url || "https://cardano.build",
    baseurl: "",
  };

  // Engine — layouts and includes use absolute paths so the standard
  // {% include nav.html %} resolves correctly.
  const engine = new Liquid({
    root: [LAYOUTS_DIR, INCLUDES_DIR],
    extname: ".html",
    cache: false,
    jekyllInclude: true, // matches Jekyll's `{% include foo.html %}` behaviour
  });

  // Custom Liquid filter: relative_url (Jekyll-style)
  engine.registerFilter("relative_url", (url) => {
    if (!url) return "";
    if (/^https?:\/\//.test(url)) return url;
    return url.startsWith("/") ? url : "/" + url;
  });

  // strip_newlines filter — Jekyll standard
  engine.registerFilter("strip_newlines", (s) => String(s ?? "").replace(/\n+/g, " ").trim());

  // Copy static assets
  await copyAssets();
  await renderSiteCss(engine, siteCtx);

  // Render every page
  const results = [];
  for (const f of PAGE_FILES) {
    if (!(await exists(path.join(ROOT, f)))) {
      console.warn(`  skip ${f} (not found)`);
      continue;
    }
    try {
      const r = await renderPage(f, engine, siteCtx);
      results.push(r);
      console.log(`  rendered ${r.src} → ${r.dst} (${r.size.toLocaleString()} bytes)`);
    } catch (e) {
      console.error(`  FAIL ${f}: ${e.message}`);
      process.exit(1);
    }
  }

  console.log(`\n✓ rendered ${results.length} pages`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
