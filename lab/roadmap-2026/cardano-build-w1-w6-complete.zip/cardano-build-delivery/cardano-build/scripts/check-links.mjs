#!/usr/bin/env node
/**
 * cardano.build — link-rot checker
 *
 * For every entry, HEAD-checks the canonical URL (and repository, docs
 * if present). Updates `last_checked` to today. Writes a report at
 * data/link-check-report.json showing which entries failed, redirected,
 * or were slow. Run nightly via CI.
 *
 * Does NOT modify status; that's a maintainer decision. The report
 * surfaces candidates for the gap tracker (W4).
 *
 * Usage:
 *   node scripts/check-links.mjs           # check + write report, don't update entries
 *   node scripts/check-links.mjs --update  # also update last_checked in entry files
 */

import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const ENTRIES_DIR = path.join(ROOT, "data/entries");
const REPORT = path.join(ROOT, "data/link-check-report.json");

const UPDATE = process.argv.includes("--update");
const TIMEOUT_MS = 12000;
const CONCURRENCY = 8;
const TODAY = new Date().toISOString().slice(0, 10);

async function checkUrl(url) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  const start = Date.now();
  try {
    // HEAD first, fall back to GET for sites that don't support HEAD
    let res = await fetch(url, {
      method: "HEAD",
      redirect: "follow",
      signal: ctrl.signal,
      headers: { "User-Agent": "cardano.build link checker (+https://cardano.build)" },
    });
    if (res.status === 405 || res.status === 501) {
      res = await fetch(url, {
        method: "GET",
        redirect: "follow",
        signal: ctrl.signal,
        headers: { "User-Agent": "cardano.build link checker (+https://cardano.build)" },
      });
    }
    return {
      ok: res.ok,
      status: res.status,
      final_url: res.url,
      redirected: res.url !== url,
      ms: Date.now() - start,
    };
  } catch (e) {
    return {
      ok: false,
      status: 0,
      error: e.name === "AbortError" ? "timeout" : e.message,
      ms: Date.now() - start,
    };
  } finally {
    clearTimeout(timer);
  }
}

async function pool(items, worker, n = CONCURRENCY) {
  const results = [];
  let idx = 0;
  async function next() {
    while (idx < items.length) {
      const my = idx++;
      results[my] = await worker(items[my]);
    }
  }
  await Promise.all(Array.from({ length: n }, next));
  return results;
}

async function main() {
  const files = (await fs.readdir(ENTRIES_DIR))
    .filter((f) => f.endsWith(".json"))
    .sort();

  const entries = [];
  for (const f of files) {
    const fp = path.join(ENTRIES_DIR, f);
    entries.push({ file: fp, data: JSON.parse(await fs.readFile(fp, "utf8")) });
  }

  console.log(`Checking ${entries.length} entries...`);

  const report = await pool(entries, async ({ file, data }) => {
    const checks = { url: await checkUrl(data.url) };
    if (data.repository) checks.repository = await checkUrl(data.repository);
    if (data.docs) checks.docs = await checkUrl(data.docs);

    const failed = Object.entries(checks)
      .filter(([, r]) => !r.ok)
      .map(([k]) => k);

    return {
      id: data.id,
      file: path.relative(ROOT, file),
      status: failed.length === 0 ? "ok" : "fail",
      failed_fields: failed,
      checks,
    };
  });

  const failing = report.filter((r) => r.status === "fail");
  console.log(
    `\n  ok: ${report.length - failing.length}  fail: ${failing.length}`
  );
  if (failing.length) {
    console.log("\nFailing entries:");
    for (const f of failing) {
      console.log(`  ${f.id} -> ${f.failed_fields.join(", ")}`);
    }
  }

  await fs.writeFile(
    REPORT,
    JSON.stringify(
      {
        generated: new Date().toISOString(),
        total: report.length,
        ok: report.length - failing.length,
        fail: failing.length,
        results: report,
      },
      null,
      2
    ) + "\n"
  );
  console.log(`\nWrote ${path.relative(ROOT, REPORT)}`);

  if (UPDATE) {
    let updated = 0;
    for (const r of report) {
      if (r.status !== "ok") continue;
      const fp = path.join(ROOT, r.file);
      const data = JSON.parse(await fs.readFile(fp, "utf8"));
      if (data.last_checked !== TODAY) {
        data.last_checked = TODAY;
        await fs.writeFile(fp, JSON.stringify(data, null, 2) + "\n");
        updated++;
      }
    }
    console.log(`Updated last_checked on ${updated} entries`);
  }

  // Exit code: 1 if any entries failed, so CI can flag without blocking.
  // Use --continue-on-error in the workflow to keep this informational.
  process.exit(failing.length > 0 ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(2);
});
