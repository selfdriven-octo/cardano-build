# Pull request notes — cardano.build W1-W6 implementation

Two options for landing this work — pick whichever fits your review style.

---

## Option A — single PR (recommended for first landing)

### Title

`Add W1–W6: persona-aware discovery layer + Jekyll source tree`

### Body

This PR is the implementation of the cardano.build roadmap published at `/ROADMAP.md`. It lands six workstreams (W1–W6) on top of the existing freeform queue without removing it — the queue keeps working as a triage inbox while typed entries take over the catalogue surface.

cardano.build asks **nothing** from the ₳3,601,926 DevX Initiative treasury. This work is funded separately through selfdriven Foundation operations and Catalyst Idea #129060. The site exists to surface the proposal's deliverables, not compete for its budget.

#### What's in here

**W1 — Persona landing pages**
- `data/personas/{evm,web2,founder}.json` — editor-curated blessed paths
- `persona.html` — shared template, reads `?p=` query param
- Persona-specific extras: EVM→Cardano translation dictionary, Web2 three-stack picker, Founder CIPs + ecosystem signals

**W2 — Machine-readable data layer**
- `schema/v1.json` (Draft 2020-12), 18 seed entries under `data/entries/`
- `scripts/build.mjs` emits `api/v1/index.json` + persona/category slices, `llms.txt`, `feed.rss`, `.well-known/mcp.json`, and a deterministic `data/snapshot.{json,digest}` for KERI anchoring
- `scripts/check-links.mjs` nightly link-rot checker
- `.github/workflows/build.yml` CI

**W3 — cardano-init and Contracts Library landings**
- `init.html` and `contracts.html` — substantive placeholder pages with pulsing "Coming Q3 2026" badges, terminal previews, stack permutations, primitive cards, and comparison tables against existing community work

**W4 — Bounties + gap tracker**
- `schema/bounty-v1.json` and `schema/gap-v1.json`
- 5 seed bounties (₳53,000 open pool), 5 seed gaps (1 resolved)
- `bounties.html` and `gaps.html` boards with filters
- Issue templates under `.github/ISSUE_TEMPLATE/`

**W5 — Measurement hackathon hub**
- `data/hackathon/measure-2026-q4.json` config for Q4 2026 event
- `measure.html` — event-meta strip, 5 metrics, 4 tracks, 6 stack permutations, sponsor invitation, CC0 data callout

**W6 — Jekyll + publish.js source tree**
- `_layouts/`, `_includes/`, `_data/` — single source of truth for nav, footer, brand strings, design tokens
- `assets/css/site.css` — shared design tokens, base typography, nav/footer/hero/section primitives
- `scripts/preview.mjs` — Node-based `liquidjs` renderer matching selfdriven Studio's `publish.js` conventions so contributors can preview locally without Ruby
- `_config.yml` + `Gemfile` for GitHub Pages
- Every page converted to Jekyll-style front matter + Liquid
- 24% LOC reduction on pages; design tokens and nav now live in one place

#### How to verify locally

```bash
npm install
npm run build         # validates schemas, emits api/v1, llms.txt, feed.rss, mcp.json
npm run preview       # renders Jekyll source to public/
cd public && python3 -m http.server 8765
```

GitHub Pages picks up `_config.yml` automatically and builds the site without any new Actions workflow needed.

#### What this does NOT do

- Does not remove `data/cardano-build.yaml` — the freeform queue still works for triage submissions that haven't been typed into entries yet.
- Does not change the existing site URL or canonical paths.
- Does not custody bounty funds or run the hackathon. cardano.build surfaces both for discoverability; the funders (CBU pool, Catalyst, Intersect, project-specific) own the actual flow.

#### What this enables

- Persona-aware navigation that filters the catalogue to what's actually relevant for an EVM dev, a Web2 dev, or a founder
- Agent-readable site map at `/llms.txt` — Claude, ChatGPT, Cursor, and the MCP-capable cohort can recommend Cardano tooling without hallucinating
- A closed-loop public record from "developer hits friction" → "gap reported" → "bounty funded" → "work shipped" → "catalogue improved"
- Discovery surfaces ready to host the proposal's deliverables (cardano-init, Contracts Library, Developer HUB) the day they ship

#### Notes for reviewers

- Each workstream has its own doc under `docs/`: `data-layer.md`, `bounties-gaps-measure.md`, `jekyll.md`
- The roadmap PDF is included in the delivery for reference; the actual roadmap content can also be authored as `ROADMAP.md` if you'd prefer a markdown source
- `assets/css/site.css` has YAML front matter to reserve future Liquid processing; remove the front matter delimiters if you'd prefer it served as a plain static file

---

## Option B — six smaller PRs

If you'd rather review and land one workstream at a time, use these commit messages and PR titles. Each one is self-contained and builds on the previous.

### PR 1 — `feat(w2): add typed catalogue schema and JSON API`

```text
Add the W2 data layer: typed catalogue entries validated against a
JSON Schema, emitted as a stable JSON API and agent-readable surfaces.

- schema/v1.json: Draft 2020-12 schema for catalogue entries
- data/entries/*.json: 18 seed entries covering current site categories
- scripts/build.mjs: validate, emit api/v1/index.json, slices, llms.txt,
  feed.rss, .well-known/mcp.json, and a snapshot digest for KERI anchoring
- scripts/check-links.mjs: nightly link-rot checker
- .github/workflows/build.yml: validate on PR, nightly link check at 14 UTC
- docs/data-layer.md: contributor guide

The freeform data/cardano-build.yaml queue is preserved unchanged.
Typed entries are an additive surface for content that's been triaged.

Funded separately through selfdriven Foundation operations and Catalyst
#129060. Nothing requested from the DevX Initiative treasury.
```

### PR 2 — `feat(w1): persona landing pages with blessed paths`

```text
Add W1 persona landing pages on top of the W2 data layer.

- data/personas/{evm,web2,founder}.json: editor-curated blessed paths
- scripts/build.mjs: validate persona configs, hydrate them with full
  entries, emit api/v1/personas/{evm,web2,founder}.json
- public/persona.html: shared template, reads ?p= query param
- Persona-specific extras:
  * EVM page gets an EVM→Cardano translation dictionary
  * Web2 page gets a three-stack picker (JS, Python, TypeScript-only)
  * Founder page gets CIP cards + ecosystem signal links
- public/index.html: persona cards link to /persona.html?p=<persona>

llms.txt now includes the persona blessed paths so coding agents
recommending Cardano tooling get the editorial guidance, not just a
flat list of links.
```

### PR 3 — `feat(w3): cardano-init and Contracts Library landings`

```text
Add W3 placeholder landings for the proposal's two headline Q3 2026
deliverables. Both pages are substantive — they show what's coming,
what to use today, and how to find the work when it ships.

- public/init.html: pulsing "Coming Q3 2026" badge, monospace headline,
  animated terminal preview with traffic-light dots, 6-feature grid,
  stack permutations matrix, 5-stage roadmap, 4 today-alternatives
- public/contracts.html: 5 primitive cards (VST/TKN/DEX/SWP/LND),
  4-stage pipeline (pick → scaffold → customise → audit), comparison
  table positioning vs existing community libraries (Anastasia,
  aicone, MuesliSwap, Minswap, SundaeSwap), 6 today-alternatives
- public/index.html: proposal banner above catalogue linking to both

When cardano-init and the Contracts Library ship from IO/CBU, these
pages become live landing surfaces; until then they hold the position
and educate.
```

### PR 4 — `feat(w4): bounty board and gap tracker`

```text
Add the W4 bounty + gap surfaces that feed the proposal's Reactive
workstream and create a public audit trail from "friction reported"
to "work shipped".

- schema/bounty-v1.json: bounty record schema. cardano.build does NOT
  custody bounty funds — every bounty links to the funder's own board.
- schema/gap-v1.json: reported gap schema with kind/severity/status
- data/bounties/*.json: 5 seed bounties, 53,000 ada open pool
- data/gaps/*.json: 5 seed gaps including 1 resolved (closed loop demo)
- public/bounties.html: filterable board with stat strip, source/status
  filters, "Open a bounty" CTA
- public/gaps.html: severity-coded board with kind/severity filters,
  resolved-gaps toggle, "Report a gap" CTA
- .github/ISSUE_TEMPLATE/{bounty,gap,entry}.md: submission templates
- scripts/build.mjs: validate bounty/gap schemas, cross-check
  linked_entry / linked_bounty references
- api/v1/bounties.json: aggregate stats + open_pool_ada
- api/v1/gaps.json: aggregate stats by status

Both surfaces are CC0. The bounty pool figure is from the seed data
and will track real funded bounties as they're posted.
```

### PR 5 — `feat(w5): measurement hackathon hub`

```text
Add the W5 hub for the Q4 2026 DevX Measurement Hackathon — a
controlled event scoped to produce the first defensible DevX baseline
for Cardano.

- data/hackathon/measure-2026-q4.json: event config
- public/measure.html: event-meta strip, 5 metrics, 4 tracks,
  6 stack permutations under test, 5-stage timeline, sponsor
  invitation, CC0 data callout
- api/v1/hackathon/measure-2026-q4.json: machine-readable event config

The measurement design is deliberately controlled: participants get
assigned stacks, problem scope is fixed, friction is logged in real
time. Output is CC0 data that future events can re-baseline against.

cardano.build hosts the hub; the event itself runs through Intersect
or IO/CBU (TBD by them).
```

### PR 6 — `refactor(w6): Jekyll source tree with publish.js preview`

```text
Refactor the standalone HTML pages onto a Jekyll-compatible source
tree with a Node-based publish.js-style offline renderer. Same source,
two render paths.

- _layouts/{default,page}.html: shared shell + hero scaffold
- _includes/{head,nav,footer}.html: shared partials
- _data/{site,nav,footer}.yml: single source of truth for brand,
  nav links, footer columns
- assets/css/site.css: shared design tokens, base typography, nav,
  footer, hero, section primitives, stat strip, CTAs, chips
- scripts/preview.mjs: liquidjs-based renderer matching selfdriven
  Studio's publish.js conventions
- _config.yml, Gemfile: GitHub Pages compatibility
- All 7 pages converted to front matter + Liquid
- docs/jekyll.md: conventions, how to add a page, dual-mode rendering

GitHub Pages picks up _config.yml and builds the site zero-config.
Contributors without Ruby can preview locally via `npm run preview`.

LOC reduction: pages dropped from 3,276 → 2,478 lines. Brand tokens,
nav links, and footer structure now live in one place each. To change
the brand colour, edit --accent in assets/css/site.css. To add a nav
link, edit _data/nav.yml.

No visual changes — verified pixel-identical to the pre-refactor
versions across all 9 page × {light, dark} combinations.
```

---

## Notes

- **Squash vs merge.** Recommended: squash-merge Option B PRs each into a single commit on `main`. That gives you a clean log where each commit on main corresponds to exactly one workstream, with the longer PR description preserved in the commit body.
- **The roadmap file itself.** Not included in the bundle as markdown — only the rendered PDF. If you want a committable markdown roadmap to land alongside this, say the word.
- **Branch naming.** Following the gitflow-ish pattern from other selfdriven repos: the single-PR branch would be `feat/w1-w6-roadmap-implementation`; the six-PR stack would be `feat/w2-data-layer`, `feat/w1-personas`, etc.
