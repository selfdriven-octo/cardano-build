# cardano.build · W1-W6 implementation bundle

This bundle contains everything to land the cardano.build roadmap implementation
in the `selfdriven-octo/cardano-build` repository.

## What's in here

| Path | What |
|---|---|
| `cardano-build/` | The repo as it should look after the PR. Drop into the existing repo. |
| `cardano-build-roadmap.pdf` | 15-page selfdriven-branded roadmap explaining the six workstreams. |
| `PR-NOTES.md` | PR descriptions and commit messages — single-PR or six-PR options. |

## Quick start

```bash
# Drop the repo contents into your local clone of selfdriven-octo/cardano-build
cd cardano-build/
npm install
npm run build         # validates schemas, emits api/v1, llms.txt, feed.rss, mcp.json
npm run preview       # renders Jekyll source to public/
cd public && python3 -m http.server 8765
```

Open http://localhost:8765 — you should see the home page with hero, persona
picker, proposal banner, and 18-entry catalogue.

## What this bundle does

Implements the six workstreams from `cardano-build-roadmap.pdf`:

- **W1** — Persona landing pages (`/persona.html?p=evm|web2|founder`)
- **W2** — Machine-readable data layer (`/api/v1/*`, `/llms.txt`, `/feed.rss`, `/.well-known/mcp.json`)
- **W3** — `cardano-init` and Contracts Library landings (proposal Q3 2026 deliverables)
- **W4** — Bounty board (`/bounties.html`) and gap tracker (`/gaps.html`)
- **W5** — Measurement hackathon hub (`/measure.html`)
- **W6** — Jekyll/publish.js source tree (Jekyll on GitHub Pages + offline preview via Node)

## What it doesn't do

- Does not custody bounty funds. cardano.build surfaces bounties; funders own the flow.
- Does not run the measurement hackathon. cardano.build hosts the hub; Intersect/IO/CBU run the event.
- Does not request anything from the ₳3.6M DevX Initiative treasury. Funded separately via
  selfdriven Foundation operations and Catalyst #129060.

## Funding context

The Cardano DevX Initiative (CBU, Q3-Q4 2026, ₳3,601,926, lead Robertino Martinez)
will ship:
- `cardano-init` starter CLI
- Cardano Contracts Library (OpenZeppelin-style primitives)
- Developer HUB at developers.cardano.org

cardano.build is the **discovery layer** that surfaces these deliverables.
The two budgets are distinct.

## Repository structure summary

```
cardano-build/
├── _config.yml                    Jekyll config for GitHub Pages
├── _data/                         Single source of truth
│   ├── site.yml                     Brand, URLs, proposal alignment
│   ├── nav.yml                      Top nav (8 items + Contribute CTA)
│   └── footer.yml                   Footer column groups
├── _includes/                     Shared HTML partials
│   ├── head.html, nav.html, footer.html
├── _layouts/                      Jekyll layouts
│   ├── default.html, page.html
├── assets/css/site.css            Shared design tokens + base styles
├── *.html                         Page sources (front matter + Liquid)
├── data/
│   ├── entries/                     18 typed catalogue entries
│   ├── personas/                    3 blessed-path configs
│   ├── bounties/                    5 seed bounties (53,000 ada open pool)
│   ├── gaps/                        5 seed gaps (1 resolved)
│   ├── hackathon/                   measure-2026-q4.json event config
│   └── cardano-build.yaml           ORIGINAL freeform queue, preserved
├── schema/
│   ├── v1.json                      Catalogue entry schema (Draft 2020-12)
│   ├── bounty-v1.json               Bounty schema
│   └── gap-v1.json                  Gap schema
├── scripts/
│   ├── build.mjs                    Validate data + emit api/v1, llms.txt, RSS, MCP
│   ├── preview.mjs                  Render Jekyll source to public/ (offline)
│   └── check-links.mjs              Nightly link-rot checker
├── docs/
│   ├── data-layer.md                W2 contributor guide
│   ├── bounties-gaps-measure.md     W4 + W5 contributor guide
│   └── jekyll.md                    W6 conventions and how-to
├── .github/
│   ├── workflows/build.yml          CI (validate on PR, nightly link check)
│   └── ISSUE_TEMPLATE/              entry, bounty, gap templates
└── public/                          Output dir for `npm run preview` (gitignore-able)
```

## License

CC0-1.0 (Public Domain). Catalogue data and schemas: same. Bounty and gap
records: CC0. Anyone can fork, reuse, or extend this without attribution.

## Contact

Maintained by selfdriven Foundation. Issues and PRs welcome.
